library(testthat)
test_check("ggbio")