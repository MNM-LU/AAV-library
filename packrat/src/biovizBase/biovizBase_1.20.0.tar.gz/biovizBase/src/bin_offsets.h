#include <Rdefines.h>

SEXP scan_bam_bin_offsets(SEXP bytes);
