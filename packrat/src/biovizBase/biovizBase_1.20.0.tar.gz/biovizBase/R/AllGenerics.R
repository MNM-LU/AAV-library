setGeneric("addStepping",function(obj,...) standardGeneric("addStepping"))

setGeneric("getFragLength", function(obj, ...) standardGeneric("getFragLength"))

setGeneric("shrinkageFun", function(obj,...) standardGeneric("shrinkageFun"))

setGeneric("maxGap", function(obj, ...) standardGeneric("maxGap"))

setGeneric("spliceSummary", function(obj, model, ...) standardGeneric("spliceSummary"))
