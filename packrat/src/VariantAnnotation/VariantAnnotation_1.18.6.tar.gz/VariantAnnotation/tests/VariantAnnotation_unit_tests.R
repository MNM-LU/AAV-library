require("VariantAnnotation") || stop("unable to load VariantAnnotation package")
VariantAnnotation:::.test()
