library(testthat);
library(VennDiagram);
test_check("VennDiagram");#This should only be used in /tests/test-all.R, and is run by R CMD check
