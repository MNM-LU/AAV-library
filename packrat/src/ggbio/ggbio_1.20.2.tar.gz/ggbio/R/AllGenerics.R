setGeneric("rescale", function(x, ...) standardGeneric("rescale"))

setGeneric("plotFragLength", function(data, model, ...)
           standardGeneric("plotFragLength"))


setGeneric("plotSpliceSum", function(data, model, ...)
           standardGeneric("plotSpliceSum"))

setGeneric("xlim",function(obj, ...) standardGeneric("xlim"))
setGeneric("xlim<-", function(x, value) standardGeneric("xlim<-"))

getGeneric("[")


