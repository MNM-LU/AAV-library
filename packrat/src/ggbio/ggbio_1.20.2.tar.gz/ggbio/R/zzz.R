.onAttach <- function(...){
  tip <- "Need specific help about ggbio? try mailing \n the maintainer or visit http://tengfei.github.com/ggbio/"
  packageStartupMessage(tip)
}
